---
name: IntelliJ plugin bug report or feature request
about: Let us know about a problem with lombok support in JetBrains IntelliJ IDEA 
title: '[DO NOT POST HERE]'
labels: ''
assignees: ''

---

***You're in the wrong place!***

Please do not report any problems or feature requests for the intellij plugin here; file these with the [intellij lombok plugin github repo](https://github.com/mplushnikov/lombok-intellij-plugin/issues).

Thank you!
