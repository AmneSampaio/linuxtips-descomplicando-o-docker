package com.sun.tools.javac.tree;

public interface EndPosTable {
	int getEndPos(JCTree tree);
}
