package com.sun.tools.javac.util;

public class Context {
	public static class Key<T> {}
}