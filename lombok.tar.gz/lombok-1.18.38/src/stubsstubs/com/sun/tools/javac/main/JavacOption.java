package com.sun.tools.javac.main;

public class JavacOption {
	public static class Option {}
}