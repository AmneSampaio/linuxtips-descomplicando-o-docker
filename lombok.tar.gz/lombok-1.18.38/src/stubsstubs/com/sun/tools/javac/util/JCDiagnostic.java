package com.sun.tools.javac.util;

public class JCDiagnostic {
	public interface DiagnosticPosition {}
}
