package com.sun.tools.javac.code;

public class Type {}