package com.sun.tools.javac.tree;

public class JCTree {
	public static class JCCompilationUnit extends JCTree {}
	public static abstract class Visitor {}
}
